# E-Commerce-App
E-Commerce Android app written in Java using Room for database support

Course project under IT306 course

Requires Jellybean (4.1) to Android (8.0) to run
